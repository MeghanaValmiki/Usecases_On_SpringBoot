package net.javaguides.sms.service;

import org.springframework.stereotype.Component;

@Component
public class LoginService {
	public boolean validateUser(String userid, String password) {
		// in28minutes, dummy
		return userid.equalsIgnoreCase("meghana")
				&& password.equalsIgnoreCase("password");
	}

}
