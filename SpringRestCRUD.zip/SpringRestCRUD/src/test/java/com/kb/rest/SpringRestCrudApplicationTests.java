package com.kb.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
